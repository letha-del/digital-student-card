# DIGITAL STUDENT CARD SYSTEM - ENHANCED VERSION WITH DATABASE, ANIMATIONS, HOVER EFFECTS, 2FA & SMARTER AI
import tkinter as tk
from tkinter import messagebox, filedialog
from tkinter.scrolledtext import ScrolledText
import hashlib
import uuid
import time
import threading
import os
import sqlite3
from PIL import Image, ImageTk

# Create and connect to SQLite database
conn = sqlite3.connect('student_system.db')
cursor = conn.cursor()
cursor.execute('''CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    password TEXT NOT NULL,
    image_path TEXT
)''')
conn.commit()

# App class
class DigitalStudentCardApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Digital Student Card")
        self.geometry("400x680")
        self.resizable(False, False)
        self.configure(bg="#e3eaf2")

        self.current_student_name = ""
        self.current_student_id = ""
        self.nfc_uid = str(uuid.uuid4())[:8]
        self.token_var = tk.StringVar()

        self.frames = {}
        for F in (LoginPage, RegisterPage, StudentCardPage, AssistantPage):
            page_name = F.__name__ # CORRECTED: Changed F._name_ to F.__name__
            frame = F(parent=self, controller=self)
            self.frames[page_name] = frame
            frame.grid(row=0, column=0, sticky="nsew")

        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)

        self.show_frame("LoginPage")
        threading.Thread(target=self.generate_token, daemon=True).start()

    def generate_token(self):
        while True:
            raw_data = self.nfc_uid + str(time.time())
            token = hashlib.sha256(raw_data.encode()).hexdigest()[:16]
            self.token_var.set(f"Token: {token}")
            time.sleep(30)

    def show_frame(self, page_name):
        frame = self.frames[page_name]
        frame.tkraise()

    def login(self, student_id, password):
        cursor.execute("SELECT name, password FROM users WHERE id=?", (student_id,))
        result = cursor.fetchone()
        if result and result[1] == password:
            current_hour = time.localtime().tm_hour
            if current_hour < 8 or current_hour >= 18:
                reason = tk.simpledialog.askstring("Unusual Login Time", "You're logging in outside of usual hours. Please provide a reason:")
                if not reason:
                    messagebox.showerror("Access Denied", "Login reason required outside normal hours.")
                    return False
            # Optional 2FA Simulation
            token = uuid.uuid4().hex[:6]
            user_input = tk.simpledialog.askstring("2FA", f"Enter 2FA Code sent to your device: {token}")
            if user_input != token:
                messagebox.showerror("2FA Failed", "Incorrect 2FA Code.")
                return False
            self.current_student_id = student_id
            self.current_student_name = result[0]
            messagebox.showinfo("Login Success", "Welcome, " + self.current_student_name + "!")
            self.show_frame("StudentCardPage")
            self.frames["StudentCardPage"].update_card_info()
            return True
        else:
            messagebox.showerror("Login Failed", "Invalid ID or Password.")
            return False

    def register(self, new_id, new_name, new_password, image_path):
        cursor.execute("SELECT id FROM users WHERE id=?", (new_id,))
        if cursor.fetchone():
            messagebox.showerror("Registration Failed", "Student ID already registered.")
            return False
        cursor.execute("INSERT INTO users (id, name, password, image_path) VALUES (?, ?, ?, ?)",
                       (new_id, new_name, new_password, image_path))
        conn.commit()
        messagebox.showinfo("Registration Success", "Account created for " + new_name + ".")
        self.show_frame("LoginPage")
        return True

    def logout(self):
        self.current_student_id = ""
        self.current_student_name = ""
        messagebox.showinfo("Logout", "You have been logged out.")
        self.show_frame("LoginPage")

# Base page
class BasePage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        self.controller = controller
        self.configure(bg="#e3eaf2")

        header = tk.Frame(self, bg="#2e86de", pady=15)
        header.pack(fill="x")
        tk.Label(header, text="DIGITAL STUDENT CARD", font=("Segoe UI", 18, "bold"), fg="white", bg="#2e86de").pack()

class LoginPage(BasePage):
    def __init__(self, parent, controller):
        super().__init__(parent, controller)

        content = tk.Frame(self, bg="white", padx=30, pady=40)
        content.pack(pady=50, padx=30, fill="both", expand=True)

        tk.Label(content, text="Login", font=("Segoe UI", 16, "bold"), bg="white").pack(pady=10)

        self.entry_id = tk.Entry(content, font=("Segoe UI", 14))
        self.entry_password = tk.Entry(content, font=("Segoe UI", 14), show="*")

        for label, entry in zip(["Student ID:", "Password:"], [self.entry_id, self.entry_password]):
            tk.Label(content, text=label, font=("Segoe UI", 12), bg="white").pack(anchor="w", pady=(10, 5))
            entry.pack(fill="x", ipady=5)

        login_btn = tk.Button(content, text="Login", command=self._perform_login, font=("Segoe UI", 14, "bold"), bg="#007bff", fg="white")
        login_btn.pack(pady=20, fill="x")
        login_btn.bind("<Enter>", lambda e: login_btn.config(bg="#0056b3"))
        login_btn.bind("<Leave>", lambda e: login_btn.config(bg="#007bff"))

        tk.Button(content, text="Register Here", command=lambda: controller.show_frame("RegisterPage"), font=("Segoe UI", 10, "underline"), bg="white", fg="#007bff", bd=0).pack()

    def _perform_login(self):
        self.controller.login(self.entry_id.get().strip(), self.entry_password.get().strip())

class RegisterPage(BasePage):
    def __init__(self, parent, controller):
        super().__init__(parent, controller)
        self.selected_image_path = None

        content = tk.Frame(self, bg="white", padx=30, pady=30)
        content.pack(pady=30, padx=30, fill="both", expand=True)

        tk.Label(content, text="Register", font=("Segoe UI", 16, "bold"), bg="white").pack(pady=10)

        self.entry_id = tk.Entry(content, font=("Segoe UI", 14))
        self.entry_name = tk.Entry(content, font=("Segoe UI", 14))
        self.entry_password = tk.Entry(content, font=("Segoe UI", 14), show="*")

        for label, entry in zip(["Student ID:", "Full Name:", "Password:"], [self.entry_id, self.entry_name, self.entry_password]):
            tk.Label(content, text=label, font=("Segoe UI", 12), bg="white").pack(anchor="w", pady=(10, 5))
            entry.pack(fill="x", ipady=5)

        tk.Button(content, text="Upload Photo", command=self._upload_photo, font=("Segoe UI", 12), bg="#6c757d", fg="white").pack(pady=(15, 5))
        tk.Button(content, text="Register", command=self._perform_register, font=("Segoe UI", 14, "bold"), bg="#28a745", fg="white").pack(pady=15, fill="x")
        tk.Button(content, text="Back", command=lambda: controller.show_frame("LoginPage"), font=("Segoe UI", 10, "underline"), bg="white", fg="#007bff", bd=0).pack()

    def _upload_photo(self):
        file_path = filedialog.askopenfilename(filetypes=[("Image files", "*.jpg *.png")])
        if file_path:
            self.selected_image_path = file_path

    def _perform_register(self):
        self.controller.register(
            self.entry_id.get().strip(),
            self.entry_name.get().strip(),
            self.entry_password.get().strip(),
            self.selected_image_path
        )

class StudentCardPage(BasePage):
    def __init__(self, parent, controller):
        super().__init__(parent, controller)

        self.card = tk.Frame(self, bg="white", padx=20, pady=20, bd=2, relief="groove")
        self.card.pack(pady=20, padx=30, fill="x")

        self.img_label = tk.Label(self.card, bg="white")
        self.label_name = tk.Label(self.card, font=("Segoe UI", 14, "bold"), bg="white")
        self.label_id = tk.Label(self.card, font=("Segoe UI", 12), bg="white")
        self.label_uid = tk.Label(self.card, font=("Segoe UI", 12), bg="white")
        self.label_token = tk.Label(self.card, textvariable=controller.token_var, font=("Courier New", 12, "bold"), bg="white", fg="#007bff")

        for widget in [self.img_label, self.label_name, self.label_id, self.label_uid, self.label_token]:
            widget.pack(pady=5, fill="x")

        tk.Button(self, text="Ask Assistant", command=lambda: controller.show_frame("AssistantPage"), font=("Segoe UI", 12), bg="#17a2b8", fg="white").pack(pady=10)
        tk.Button(self, text="Logout", command=controller.logout, font=("Segoe UI", 12), bg="#dc3545", fg="white").pack()

    def update_card_info(self):
        sid = self.controller.current_student_id
        cursor.execute("SELECT name, image_path FROM users WHERE id=?", (sid,))
        result = cursor.fetchone()
        if result:
            name, img_path = result
            if img_path and os.path.exists(img_path):
                img = Image.open(img_path).resize((100, 100))
                self.photo = ImageTk.PhotoImage(img)
                self.img_label.config(image=self.photo)
            else:
                self.img_label.config(image="")

            self.label_name.config(text=f"Name: {name}")
            self.label_id.config(text=f"Student ID: {sid}")
            self.label_uid.config(text=f"NFC UID: {self.controller.nfc_uid}")

class AssistantPage(BasePage):
    def __init__(self, parent, controller):
        super().__init__(parent, controller)

        self.chat_area = ScrolledText(self, wrap="word", font=("Segoe UI", 12), bg="white", fg="black")
        self.chat_area.pack(padx=20, pady=20, fill="both", expand=True)
        self.chat_area.insert("end", "Assistant: Hi! I can help explain how the system works — NFC, tokens, logins, 2FA, and more!\n\n")
        self.chat_area.config(state="disabled")

        self.user_entry = tk.Entry(self, font=("Segoe UI", 12), bg="#f0f0f0")
        self.user_entry.pack(padx=20, pady=(0, 10), fill="x")
        self.user_entry.bind("<Return>", self.handle_user_input)

        tk.Button(self, text="Back", command=lambda: controller.show_frame("StudentCardPage"), font=("Segoe UI", 12), bg="#6c757d", fg="white").pack(pady=(0, 10))

    def handle_user_input(self, event=None):
        msg = self.user_entry.get().strip()
        if not msg:
            return
        self.user_entry.delete(0, "end")
        self.append_chat("You", msg)
        response = self.get_response(msg)
        self.append_chat("Assistant", response)

    def append_chat(self, sender, message):
        self.chat_area.config(state="normal")
        self.chat_area.insert("end", f"{sender}: {message}\n\n")
        self.chat_area.config(state="disabled")
        self.chat_area.see("end")

    def get_response(self, msg):
        msg = msg.lower()
        if "nfc" in msg or "how it works" in msg:
            return "We use NFC to generate a unique UID and secure token every 30 seconds for validation."
        elif "late" in msg or "outside" in msg:
            return "Outside 8 AM - 6 PM, you must give a valid reason to login."
        elif "token" in msg:
            return "The token is generated with SHA-256 hashing using your UID and current time."
        elif "2fa" in msg:
            return "Two-Factor Authentication (2FA) is used during login to protect your account with an extra code."
        elif "photo" in msg:
            return "You can upload a photo when registering. It will show on your student card."
        else:
            return "Ask me about security, login, tokens, NFC, or 2FA!"

# --- Main Application Execution ---
if __name__ == "__main__":
    app = DigitalStudentCardApp()
    print("Attempting to open Tkinter window...")
    app.mainloop()